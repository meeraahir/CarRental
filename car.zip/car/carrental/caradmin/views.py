from django.contrib.auth.models import User
from django.shortcuts import render, redirect, get_object_or_404

from .models import *
from django.urls import reverse

from caruser.models import BookCar


# Create your views here.
def admindashboard(request):
    total_car = Addcar.objects.count()
    total_user = User.objects.filter(is_superuser=False).count()
    total_order=BookCar.objects.filter(status='Accepted').count()

    car_add_url = reverse('caradmin_app:car_add')
    context = {
        'total_car': total_car,
        'car_add_url': car_add_url,
        'total_user': total_user,
        'total_order':total_order

    }
    return render(request, 'admin/admin_dashboard.html', context)

def base(request):
    return render(request,'admin/base.html')

def base1(request):
    return render(request,'admin/base1.html')
def add_car(request):
    if request.method == 'POST':
        cname = request.POST['car_name']
        des = request.POST['car_description']
        rent = request.POST['car_rent']
        img = request.FILES['car_image']
        city = request.POST['car_city']
        state = request.POST['car_state']
        pin = request.POST['car_pincode']
        availability = request.POST['car_availability']
        seat = request.POST['car_seater']
        ctype = request.POST['car_type']

        car = Addcar.objects.create(
            car_name=cname,
            car_description=des,
            car_rent=rent,
            car_image=img,
            car_city=city,
            car_state=state,
            car_pincode=pin,
            car_availability=availability,
            car_seater=seat,
            car_type=ctype,
        )
        car.save()
        return redirect('caradmin_app:admin_dashboard')
    return render(request, 'admin/car_add.html')


def view_car(request):
    cars=Addcar.objects.all()
    context = {'cars': cars}
    return render(request, 'admin/view_car.html',context)


def view_order(request):
    car=BookCar.objects.all()
    context ={'car':car}
    return render(request,'admin/view_order.html',context)
def update_car(request, id):
    c = Addcar.objects.get(id=id)

    if request.method == 'POST':
        cname = request.POST['car_name']
        des = request.POST.get('car_description', c.car_description)
        rent = request.POST['car_rent']
        img = request.FILES.get('car_image', c.car_image)
        city = request.POST['car_city']
        state = request.POST['car_state']
        pin = request.POST['car_pincode']
        availability = request.POST.get('car_availability', c.car_availability)
        seat = request.POST.get('car_seater', c.car_seater)
        ctype = request.POST.get('car_type', c.car_type)

        c.car_name = cname
        c.car_description = des
        c.car_rent = rent
        c.car_image = img
        c.car_city = city
        c.car_state = state
        c.car_pincode = pin
        c.car_availability = availability
        c.car_seater = seat
        c.car_type = ctype
        c.save()
        return redirect('caradmin_app:view_car')

    return render(request, 'admin/update_car.html', {'c': c})



def delete_car(request,id):
    c=Addcar.objects.get(id=id)
    c.delete()
    return redirect('caradmin_app:view_car')


def accept_order(request,order_id):
    order=get_object_or_404(BookCar,id=order_id)
    order.status= 'Accepted'
    order.save()
    return redirect('caradmin_app:view_order')


def reject_order(request,order_id):
    order=get_object_or_404(BookCar,id=order_id)
    order.status='Rejected'
    order.save()
    return redirect('caradmin_app:view_order')