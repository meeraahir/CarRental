from . import views
from django.urls import path, include

app_name = 'caradmin_app'
urlpatterns = [

    path('admin_dashboard/',views.admindashboard,name='admin_dashboard'),
    path('base/',views.base,name='base'),
    path('base1/',views.base1,name='base1'),
    path('car_add/',views.add_car,name='car_add'),
    path('view_car/', views.view_car, name='view_car'),
    path('update_car/<int:id>/', views.update_car, name='update_car'),
    path('delete_car/<int:id>/', views.delete_car, name='delete_car'),
    path('view_order/',views.view_order,name='view_order'),
    path('accept_order/<int:order_id>/', views.accept_order, name='accept_order'),
    path('reject_order/<int:order_id>/', views.reject_order, name='reject_order'),
]