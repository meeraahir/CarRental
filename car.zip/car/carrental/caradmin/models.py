from django.db import models

# Create your models here.
class Addcar(models.Model):
    car_name=models.CharField(max_length=50)
    car_description=models.TextField()
    car_rent=models.IntegerField()
    car_image=models.ImageField(upload_to='media/')
    car_city=models.CharField(max_length=50)
    car_state=models.CharField(max_length=50)
    car_pincode=models.CharField(max_length=10)
    car_availability=models.CharField(max_length=10)
    car_seater=models.IntegerField()
    car_type=models.CharField(max_length=10)


