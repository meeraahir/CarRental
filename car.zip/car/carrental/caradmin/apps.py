from django.apps import AppConfig


class CaradminConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'caradmin'
