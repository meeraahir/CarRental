from . import views
from django.urls import path

urlpatterns = [
    path('', views.index, name='index'),
    path('about/', views.about, name='about'),
    path('blog/', views.blog, name='blog'),
    path('blog-single/', views.blogsingle, name='blogsingle'),
    path('car/', views.car, name='car'),
    path('order/',views.order,name='order'),
    path('car-single/<int:id>/', views.carsingle, name='carsingle'),
    path('contact/', views.contact, name='contact'),
    path('main/', views.main, name='main'),
    path('pricing/', views.pricing, name='pricing'),
    path('services/', views.services, name='services'),
    path('login/', views.user_login, name='login'),
    path('registration/',views.signUp,name='registration'),
    path('logout/',views.logout,name='logout'),
    path('car_search/',views.car_search,name='car_search'),
    path('book_car/<int:id>/',views.book_car,name='book_car'),
    path('userbase',views.userbase,name='userbase'),


]