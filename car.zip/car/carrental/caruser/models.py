from django.contrib.auth.models import User
from django.db import models

from caradmin.models import Addcar


# Create your models here.

class UserProfile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    phoneNo = models.CharField(max_length=15)
    city = models.CharField(max_length=100)
    state = models.CharField(max_length=100)

class BookCar(models.Model):
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('confirm', 'Confirm'),
    ]

    user=models.ForeignKey(User,on_delete=models.CASCADE)
    car=models.ForeignKey(Addcar,on_delete=models.CASCADE)
    days=models.IntegerField()
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )
