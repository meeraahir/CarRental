import logging

from django.conf import settings
from django.contrib import messages
from django.contrib.auth.decorators import login_required

from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db.models import Sum
from django.http import HttpResponseRedirect, HttpResponse
from django.shortcuts import render, redirect, get_object_or_404

from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth import logout as auth_logout
from .models import *
from caradmin.models import Addcar


# Create your views here.
def index(request):
    return render(request,'index.html')

def about(request):
    return render(request,'user/about.html')

def blog(request):
    return render(request,'user/blog.html')

def blogsingle(request):
    return render(request,'user/blog-single.html')

def car(request):
    cars = Addcar.objects.all()
    context = {'cars': cars}
    return render(request, 'user/car.html', context)


def carsingle(request,id):
    cars = Addcar.objects.all()
    car = get_object_or_404(cars, id=id)
    return render(request,'user/car-single.html',{'car':car})

def contact(request):
    return render(request,'user/contact.html')


def main(request):
    return render(request,'user/main.html')

def pricing(request):
    return render(request,'user/pricing.html')


def services(request):
    return render(request,'user/services.html')



logger = logging.getLogger(__name__)


def user_login(request):

        if request.method == 'POST':
            username = request.POST.get('username')
            password = request.POST.get('password')

            user_obj = authenticate(username=username, password=password)
            if user_obj is None:
                print("Authentication failed")
                messages.info(request, 'Invalid username or password. Please try again.')
                return redirect('login')

            auth_login(request, user_obj)

            if user_obj.is_superuser:
                return redirect('caradmin_app:admin_dashboard')
            else:
                return redirect('index')

        return render(request, 'login.html')




def signUp(request):
    if request.method == 'POST':
        fname = request.POST['first_name']
        lname = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        pno = request.POST['phoneNo']
        city = request.POST['city']
        state = request.POST['state']
        password = request.POST['password']
        cpassword = request.POST['confirm_password']

        # Email and username validation
        if User.objects.filter(username=username).exists():
            messages.error(request, "Username already exists! Please try another username.")
            return redirect('registration')

        if User.objects.filter(email=email).exists():
            messages.error(request, "Email is already registered.")
            return redirect('registration')

        if len(username) > 10:
            messages.error(request, "Username must be under 10 characters.")
            return redirect('registration')

        if password != cpassword:
            messages.error(request, "Passwords didn't match.")
            return redirect('registration')

        if not username.isalnum():
            messages.error(request, "Username must be alphanumeric.")
            return redirect('registration')

        # Creating the user
        myuser = User.objects.create_user(username=username, email=email, password=password)
        myuser.first_name = fname
        myuser.last_name = lname
        myuser.is_active = True
        myuser.save()

        # Creating the user profile
        user_profile = UserProfile(user=myuser, phoneNo=pno, city=city, state=state)
        user_profile.save()

        messages.success(request,
                         "Your account has been successfully created. We have sent you a confirmation email to activate your account.")

        # Send welcome email
        subject = "Welcome to CarRental Website!"
        message = f"Hello {myuser.first_name}!! \nWelcome to CarRental Website! \nThank you for visiting our website. \nWe have also sent you a confirmation email, please confirm your email address to activate your account. \n\nThank you,\nMeera Ahir"
        from_email = settings.EMAIL_HOST_USER
        to_list = [myuser.email]
        send_mail(subject, message, from_email, to_list, fail_silently=True)

        return redirect('login')
    return render(request,'registration.html')


def logout(request):
    auth_logout(request)
    return redirect('index')

def car_search(request):
    query=request.GET.get('query')
    cars=Addcar.objects.filter(car_city__icontains=query) if query else Addcar.objects.all()
    return render(request,'user/car.html',{'cars':cars})

@login_required
def book_car(request,id):
    if request.method == 'POST':
        user =request.user
        car=get_object_or_404(Addcar,id=id)
        days=request.POST.get('days')

        if not days or not days.isdigit() or int(days) <=0:
            return render(request,'user/car-single.html',{'error':'please enter valid Days'})

        days=int(days)

        booking=BookCar(user=user,car=car,days=days)
        booking.save()
        return redirect('order')
    return render(request,'user/order.html',{'id':id})


def order(request):
    user = request.user
    bookings = BookCar.objects.filter(user=user)

    for booking in bookings:
        booking.total_rent = booking.car.car_rent * booking.days

    rent_per_type = Addcar.objects.values('car_type').annotate(total_rent=Sum('car_rent')).order_by('car_type')

    context = {
        'bookings': bookings,
        'rent_per_type': rent_per_type
    }
    return render(request,'user/order.html',context)


def userbase(request):
    return render(request,'userbase.html')